This is my web application that allows users to post or view odd or casual jobs.
